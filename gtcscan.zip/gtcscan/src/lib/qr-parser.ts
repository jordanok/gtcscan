/**
 * QR Code Data Parser
 * Parses various QR code types and extracts meaningful information
 */

export type QRCodeType = 
  | 'url' 
  | 'wifi' 
  | 'vcard' 
  | 'geo' 
  | 'email' 
  | 'sms' 
  | 'tel' 
  | 'event' 
  | 'text';

export interface ParsedWiFi {
  ssid: string;
  password: string;
  security: 'WPA' | 'WEP' | 'WPA2-EAP' | 'nopass' | 'Unknown';
  hidden: boolean;
}

export interface ParsedVCard {
  name?: string;
  fullName?: string;
  phone?: string[];
  email?: string[];
  organization?: string;
  title?: string;
  address?: string;
  url?: string[];
  note?: string;
}

export interface ParsedGeo {
  latitude: number;
  longitude: number;
  altitude?: number;
  label?: string;
}

export interface ParsedEmail {
  to: string;
  subject?: string;
  body?: string;
  cc?: string;
  bcc?: string;
}

export interface ParsedSMS {
  number: string;
  body?: string;
}

export interface ParsedEvent {
  summary?: string;
  description?: string;
  location?: string;
  startDate?: Date;
  endDate?: Date;
}

export interface ParsedQRData {
  type: QRCodeType;
  raw: string;
  parsed?: ParsedWiFi | ParsedVCard | ParsedGeo | ParsedEmail | ParsedSMS | ParsedEvent | string;
  displayText: string;
}

/**
 * Detect QR code type and parse accordingly
 */
export function parseQRData(data: string): ParsedQRData {
  if (!data || typeof data !== 'string') {
    return { type: 'text', raw: data, displayText: data };
  }

  const trimmedData = data.trim();

  // URL detection
  if (isURL(trimmedData)) {
    return {
      type: 'url',
      raw: trimmedData,
      parsed: trimmedData,
      displayText: trimmedData
    };
  }

  // WiFi detection (WIFI:T:WPA;S:MyNetwork;P:MyPassword;;)
  if (trimmedData.startsWith('WIFI:')) {
    return parseWiFi(trimmedData);
  }

  // vCard detection
  if (trimmedData.startsWith('BEGIN:VCARD')) {
    return parseVCard(trimmedData);
  }

  // Geo location detection (geo:lat,lon or geo:lat,lon,alt)
  if (trimmedData.startsWith('geo:')) {
    return parseGeo(trimmedData);
  }

  // Email detection (mailto:)
  if (trimmedData.startsWith('mailto:')) {
    return parseEmail(trimmedData);
  }

  // SMS detection (sms: or smsto:)
  if (trimmedData.startsWith('sms:') || trimmedData.startsWith('smsto:')) {
    return parseSMS(trimmedData);
  }

  // Phone detection (tel:)
  if (trimmedData.startsWith('tel:')) {
    return parseTel(trimmedData);
  }

  // Calendar event detection (BEGIN:VEVENT)
  if (trimmedData.includes('BEGIN:VEVENT') || trimmedData.startsWith('BEGIN:VCALENDAR')) {
    return parseEvent(trimmedData);
  }

  // Default to plain text
  return {
    type: 'text',
    raw: trimmedData,
    displayText: trimmedData
  };
}

/**
 * Check if string is a valid URL
 */
function isURL(str: string): boolean {
  try {
    const url = new URL(str);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch {
    // Also check for common URL patterns without protocol
    const urlPattern = /^(www\.)?[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+(\/[^\s]*)?$/i;
    return urlPattern.test(str);
  }
}

/**
 * Parse WiFi QR code
 * Format: WIFI:T:WPA;S:MyNetwork;P:MyPassword;H:true;;
 */
function parseWiFi(data: string): ParsedQRData {
  const result: ParsedWiFi = {
    ssid: '',
    password: '',
    security: 'Unknown',
    hidden: false
  };

  // Remove WIFI: prefix and trailing ;;
  const content = data.replace(/^WIFI:/, '').replace(/;;$/, '');
  
  // Parse key-value pairs
  const parts = content.split(';');
  for (const part of parts) {
    const colonIndex = part.indexOf(':');
    if (colonIndex === -1) continue;
    
    const key = part.substring(0, colonIndex).toUpperCase();
    const value = part.substring(colonIndex + 1);
    
    // Handle escaped characters
    const unescapedValue = unescapeWifiValue(value);
    
    switch (key) {
      case 'T':
        result.security = mapSecurityType(unescapedValue);
        break;
      case 'S':
        result.ssid = unescapedValue;
        break;
      case 'P':
        result.password = unescapedValue;
        break;
      case 'H':
        result.hidden = unescapedValue.toLowerCase() === 'true';
        break;
    }
  }

  return {
    type: 'wifi',
    raw: data,
    parsed: result,
    displayText: `WiFi: ${result.ssid}`
  };
}

/**
 * Unescape WiFi special characters
 */
function unescapeWifiValue(value: string): string {
  return value
    .replace(/\\:/g, ':')
    .replace(/\\;/g, ';')
    .replace(/\\\\/g, '\\')
    .replace(/\\,/g, ',');
}

/**
 * Map security type string to enum
 */
function mapSecurityType(type: string): ParsedWiFi['security'] {
  const normalized = type.toUpperCase().replace(/[-\s]/g, '');
  if (normalized === 'WPA' || normalized === 'WPAPSK') return 'WPA';
  if (normalized === 'WPA2EAP' || normalized === 'WPA2-EAP') return 'WPA2-EAP';
  if (normalized === 'WEP') return 'WEP';
  if (normalized === 'NOPASS' || normalized === '' || normalized === 'NONE') return 'nopass';
  return 'Unknown';
}

/**
 * Parse vCard QR code
 */
function parseVCard(data: string): ParsedQRData {
  const result: ParsedVCard = {};
  const lines = data.split(/\r?\n/);

  for (const line of lines) {
    const colonIndex = line.indexOf(':');
    if (colonIndex === -1) continue;

    const key = line.substring(0, colonIndex).toUpperCase();
    const value = line.substring(colonIndex + 1);

    switch (key) {
      case 'FN':
        result.fullName = decodeVCardValue(value);
        break;
      case 'N':
        const nameParts = value.split(';');
        result.name = nameParts.filter(Boolean).reverse().join(' ');
        break;
      case 'TEL':
      case 'TEL;TYPE=CELL':
      case 'TEL;TYPE=WORK':
      case 'TEL;TYPE=HOME':
        if (!result.phone) result.phone = [];
        result.phone.push(decodeVCardValue(value));
        break;
      case 'EMAIL':
      case 'EMAIL;TYPE=WORK':
      case 'EMAIL;TYPE=HOME':
        if (!result.email) result.email = [];
        result.email.push(decodeVCardValue(value));
        break;
      case 'ORG':
        result.organization = decodeVCardValue(value);
        break;
      case 'TITLE':
        result.title = decodeVCardValue(value);
        break;
      case 'ADR':
      case 'ADR;TYPE=WORK':
      case 'ADR;TYPE=HOME':
        const addrParts = value.split(';');
        result.address = addrParts.filter(Boolean).join(', ');
        break;
      case 'URL':
        if (!result.url) result.url = [];
        result.url.push(decodeVCardValue(value));
        break;
      case 'NOTE':
        result.note = decodeVCardValue(value);
        break;
    }
  }

  return {
    type: 'vcard',
    raw: data,
    parsed: result,
    displayText: result.fullName || result.name || 'Contact Card'
  };
}

/**
 * Decode vCard escaped values
 */
function decodeVCardValue(value: string): string {
  return value
    .replace(/\\n/gi, '\n')
    .replace(/\\,/g, ',')
    .replace(/\\;/g, ';')
    .replace(/\\\\/g, '\\');
}

/**
 * Parse geo location QR code
 * Format: geo:lat,lon or geo:lat,lon,alt
 */
function parseGeo(data: string): ParsedQRData {
  const content = data.replace(/^geo:/, '');
  const params = content.split('?');
  const coords = params[0].split(',');
  
  const result: ParsedGeo = {
    latitude: parseFloat(coords[0]) || 0,
    longitude: parseFloat(coords[1]) || 0,
    altitude: coords[2] ? parseFloat(coords[2]) : undefined
  };

  // Parse label from query params
  if (params[1]) {
    const searchParams = new URLSearchParams(params[1]);
    result.label = searchParams.get('label') || searchParams.get('q') || undefined;
  }

  return {
    type: 'geo',
    raw: data,
    parsed: result,
    displayText: `${result.latitude}, ${result.longitude}`
  };
}

/**
 * Parse email QR code
 * Format: mailto:email?subject=...&body=...
 */
function parseEmail(data: string): ParsedQRData {
  const content = data.replace(/^mailto:/, '');
  const parts = content.split('?');
  
  const result: ParsedEmail = {
    to: decodeURIComponent(parts[0])
  };

  if (parts[1]) {
    const searchParams = new URLSearchParams(parts[1]);
    result.subject = searchParams.get('subject') || undefined;
    result.body = searchParams.get('body') || undefined;
    result.cc = searchParams.get('cc') || undefined;
    result.bcc = searchParams.get('bcc') || undefined;
  }

  return {
    type: 'email',
    raw: data,
    parsed: result,
    displayText: result.to
  };
}

/**
 * Parse SMS QR code
 * Format: sms:number?body=... or smsto:number:message
 */
function parseSMS(data: string): ParsedQRData {
  let content = data.replace(/^sms:/, '').replace(/^smsto:/, '');
  
  const result: ParsedSMS = {
    number: '',
    body: undefined
  };

  // Check for query string format
  if (content.includes('?')) {
    const parts = content.split('?');
    result.number = decodeURIComponent(parts[0]);
    const searchParams = new URLSearchParams(parts[1]);
    result.body = searchParams.get('body') || undefined;
  } else if (content.includes(':')) {
    // smsto:number:message format
    const parts = content.split(':');
    result.number = parts[0];
    result.body = parts.slice(1).join(':') || undefined;
  } else {
    result.number = content;
  }

  return {
    type: 'sms',
    raw: data,
    parsed: result,
    displayText: result.number
  };
}

/**
 * Parse telephone QR code
 * Format: tel:number
 */
function parseTel(data: string): ParsedQRData {
  const number = data.replace(/^tel:/, '');
  
  return {
    type: 'tel',
    raw: data,
    parsed: number,
    displayText: number
  };
}

/**
 * Parse calendar event QR code
 */
function parseEvent(data: string): ParsedQRData {
  const result: ParsedEvent = {};
  const lines = data.split(/\r?\n/);

  for (const line of lines) {
    const colonIndex = line.indexOf(':');
    if (colonIndex === -1) continue;

    const key = line.substring(0, colonIndex).toUpperCase();
    const value = line.substring(colonIndex + 1);

    switch (key) {
      case 'SUMMARY':
        result.summary = value;
        break;
      case 'DESCRIPTION':
        result.description = value.replace(/\\n/g, '\n');
        break;
      case 'LOCATION':
        result.location = value;
        break;
      case 'DTSTART':
        result.startDate = parseICalDate(value);
        break;
      case 'DTEND':
        result.endDate = parseICalDate(value);
        break;
    }
  }

  return {
    type: 'event',
    raw: data,
    parsed: result,
    displayText: result.summary || 'Calendar Event'
  };
}

/**
 * Parse iCalendar date format
 */
function parseICalDate(value: string): Date | undefined {
  // Basic iCalendar date parsing (YYYYMMDDTHHMMSSZ)
  const match = value.match(/(\d{4})(\d{2})(\d{2})T?(\d{2})?(\d{2})?(\d{2})?(Z)?/);
  if (match) {
    const [, year, month, day, hour = '0', minute = '0', second = '0'] = match;
    return new Date(
      parseInt(year),
      parseInt(month) - 1,
      parseInt(day),
      parseInt(hour),
      parseInt(minute),
      parseInt(second)
    );
  }
  return undefined;
}

/**
 * Get type label for display
 */
export function getTypeLabel(type: QRCodeType): string {
  const labels: Record<QRCodeType, string> = {
    url: 'URL / Website',
    wifi: 'WiFi Network',
    vcard: 'Contact Card',
    geo: 'Location',
    email: 'Email',
    sms: 'SMS Message',
    tel: 'Phone Number',
    event: 'Calendar Event',
    text: 'Plain Text'
  };
  return labels[type];
}

/**
 * Get icon name for type
 */
export function getTypeIcon(type: QRCodeType): string {
  const icons: Record<QRCodeType, string> = {
    url: 'Globe',
    wifi: 'Wifi',
    vcard: 'User',
    geo: 'MapPin',
    email: 'Mail',
    sms: 'MessageSquare',
    tel: 'Phone',
    event: 'Calendar',
    text: 'FileText'
  };
  return icons[type];
}

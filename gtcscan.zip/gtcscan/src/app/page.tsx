'use client'

import { useState, useRef, useCallback, useEffect } from 'react'
import jsQR from 'jsqr'
import { 
  QrCode, Upload, Camera, CameraOff, Copy, Check, ExternalLink, 
  Wifi, User, MapPin, Mail, MessageSquare, Phone, Calendar, FileText,
  Globe, Shield, AlertCircle, CheckCircle, Info
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert'
import { Separator } from '@/components/ui/separator'
import { toast } from '@/hooks/use-toast'
import { parseQRData, getTypeLabel, type ParsedQRData, type QRCodeType } from '@/lib/qr-parser'
import { FAQItem } from '@/components/faq-item'

// QR Code type information for the table
const qrCodeTypes = [
  { type: 'URL', icon: 'Globe', description: 'Website links that open in browser', example: 'https://example.com' },
  { type: 'WiFi', icon: 'Wifi', description: 'Network credentials for easy connection', example: 'WIFI:T:WPA;S:Network;P:Password;;' },
  { type: 'vCard', icon: 'User', description: 'Contact information for quick saving', example: 'BEGIN:VCARD...' },
  { type: 'Location', icon: 'MapPin', description: 'Geographic coordinates for maps', example: 'geo:37.7749,-122.4194' },
  { type: 'Email', icon: 'Mail', description: 'Pre-filled email composition', example: 'mailto:email@example.com' },
  { type: 'SMS', icon: 'MessageSquare', description: 'Text message with recipient', example: 'sms:+1234567890' },
  { type: 'Phone', icon: 'Phone', description: 'Click-to-call phone numbers', example: 'tel:+1234567890' },
  { type: 'Event', icon: 'Calendar', description: 'Calendar event details', example: 'BEGIN:VEVENT...' },
  { type: 'Text', icon: 'FileText', description: 'Plain text content', example: 'Any text content' },
]

// FAQ items
const faqItems = [
  {
    question: 'Is my data sent to any server?',
    answer: 'No. All QR code scanning happens entirely in your browser. Your images and camera feed are processed locally using JavaScript, ensuring complete privacy. No data is ever uploaded to any server.'
  },
  {
    question: 'What image formats are supported?',
    answer: 'We support all common image formats including PNG, JPEG, GIF, BMP, and WebP. You can drag and drop images or use the file picker to select them.'
  },
  {
    question: 'Why is my camera not working?',
    answer: 'Make sure you\'ve granted camera permissions in your browser. If you\'re using HTTPS (required for camera access), ensure your connection is secure. Some browsers may require you to reload the page after granting permissions.'
  },
  {
    question: 'Can I scan multiple QR codes at once?',
    answer: 'Currently, the scanner processes one QR code at a time. For webcam scanning, it continuously looks for QR codes until one is found. You can scan again after viewing the result.'
  },
  {
    question: 'What if the QR code is not recognized?',
    answer: 'Ensure the QR code is clearly visible, well-lit, and not damaged. For images, try using a higher resolution image. For webcam scanning, hold the QR code steady and at an appropriate distance from the camera.'
  }
]

export default function QRScanner() {
  const [activeTab, setActiveTab] = useState('upload')
  const [scannedData, setScannedData] = useState<ParsedQRData | null>(null)
  const [isScanning, setIsScanning] = useState(false)
  const [isDragging, setIsDragging] = useState(false)
  const [copied, setCopied] = useState(false)
  const [cameraActive, setCameraActive] = useState(false)
  const [cameraError, setCameraError] = useState<string | null>(null)
  
  const fileInputRef = useRef<HTMLInputElement>(null)
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const animationFrameRef = useRef<number | null>(null)

  // Stop camera - defined early for use in cleanup
  const stopCamera = useCallback(() => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current)
      animationFrameRef.current = null
    }
    
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    
    if (videoRef.current) {
      videoRef.current.srcObject = null
    }
    
    setCameraActive(false)
  }, [])

  // Cleanup camera on unmount
  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [stopCamera])

  // Copy to clipboard
  const copyToClipboard = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopied(true)
      toast({ title: 'Copied!', description: 'Content copied to clipboard' })
      setTimeout(() => setCopied(false), 2000)
    } catch {
      toast({ title: 'Error', description: 'Failed to copy to clipboard', variant: 'destructive' })
    }
  }

  // Process image file
  const processImage = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) {
      toast({ title: 'Invalid file', description: 'Please select an image file', variant: 'destructive' })
      return
    }

    setIsScanning(true)
    setScannedData(null)

    const reader = new FileReader()
    reader.onload = (e) => {
      const img = new Image()
      img.onload = () => {
        const canvas = document.createElement('canvas')
        const ctx = canvas.getContext('2d')
        if (!ctx) {
          setIsScanning(false)
          return
        }

        canvas.width = img.width
        canvas.height = img.height
        ctx.drawImage(img, 0, 0)

        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
        const code = jsQR(imageData.data, imageData.width, imageData.height, {
          inversionAttempts: 'dontInvert'
        })

        if (code) {
          const parsed = parseQRData(code.data)
          setScannedData(parsed)
          toast({ title: 'QR Code Found!', description: `Type: ${getTypeLabel(parsed.type)}` })
        } else {
          toast({ title: 'No QR Code Found', description: 'Try a different image or ensure the QR code is clearly visible', variant: 'destructive' })
        }
        setIsScanning(false)
      }
      img.src = e.target?.result as string
    }
    reader.readAsDataURL(file)
  }, [])

  // Handle file drop
  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    
    const file = e.dataTransfer.files[0]
    if (file) {
      processImage(file)
    }
  }, [processImage])

  // Handle file selection
  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      processImage(file)
    }
  }, [processImage])

  // Start camera
  const startCamera = async () => {
    try {
      setCameraError(null)
      setScannedData(null)
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment' }
      })
      
      streamRef.current = stream
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream
        videoRef.current.play()
        setCameraActive(true)
        scanQRFromVideo()
      }
    } catch (err) {
      console.error('Camera error:', err)
      if (err instanceof Error) {
        if (err.name === 'NotAllowedError') {
          setCameraError('Camera access denied. Please allow camera permissions in your browser settings.')
        } else if (err.name === 'NotFoundError') {
          setCameraError('No camera found on this device.')
        } else {
          setCameraError(`Camera error: ${err.message}`)
        }
      } else {
        setCameraError('Failed to access camera. Please check your camera permissions.')
      }
    }
  }

  // Scan QR from video stream
  const scanQRFromVideo = () => {
    if (!videoRef.current || !canvasRef.current) {
      animationFrameRef.current = requestAnimationFrame(scanQRFromVideo)
      return
    }

    const video = videoRef.current
    const canvas = canvasRef.current
    const ctx = canvas.getContext('2d')

    if (!ctx || video.readyState !== video.HAVE_ENOUGH_DATA) {
      animationFrameRef.current = requestAnimationFrame(scanQRFromVideo)
      return
    }

    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)

    const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height)
    const code = jsQR(imageData.data, imageData.width, imageData.height, {
      inversionAttempts: 'dontInvert'
    })

    if (code) {
      const parsed = parseQRData(code.data)
      setScannedData(parsed)
      stopCamera()
      toast({ title: 'QR Code Scanned!', description: `Type: ${getTypeLabel(parsed.type)}` })
      return
    }

    animationFrameRef.current = requestAnimationFrame(scanQRFromVideo)
  }

  // Get icon component by type
  const getTypeIconComponent = (type: QRCodeType) => {
    const icons: Record<QRCodeType, React.ElementType> = {
      url: Globe,
      wifi: Wifi,
      vcard: User,
      geo: MapPin,
      email: Mail,
      sms: MessageSquare,
      tel: Phone,
      event: Calendar,
      text: FileText
    }
    return icons[type]
  }

  // Render scanned data based on type
  const renderScannedData = () => {
    if (!scannedData) return null

    const Icon = getTypeIconComponent(scannedData.type)

    return (
      <Card className="overflow-hidden">
        <CardHeader className="pb-3">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-primary/10">
              <Icon className="w-5 h-5 text-primary" />
            </div>
            <div>
              <CardTitle className="text-lg">{getTypeLabel(scannedData.type)}</CardTitle>
              <CardDescription>QR code successfully decoded</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Type-specific display */}
          {scannedData.type === 'url' && (
            <div className="space-y-2">
              <a 
                href={scannedData.raw.startsWith('www.') ? `https://${scannedData.raw}` : scannedData.raw}
                target="_blank"
                rel="noopener noreferrer"
                className="text-primary hover:underline flex items-center gap-1 break-all"
              >
                {scannedData.raw}
                <ExternalLink className="w-4 h-4 flex-shrink-0" />
              </a>
            </div>
          )}

          {scannedData.type === 'wifi' && scannedData.parsed && (
            <div className="space-y-3">
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div className="font-medium text-muted-foreground">Network</div>
                <div className="font-medium">{(scannedData.parsed as any).ssid || 'Unknown'}</div>
                
                <div className="font-medium text-muted-foreground">Security</div>
                <div className="font-medium">{(scannedData.parsed as any).security}</div>
                
                {(scannedData.parsed as any).password && (
                  <>
                    <div className="font-medium text-muted-foreground">Password</div>
                    <div className="font-medium font-mono flex items-center gap-2">
                      {(scannedData.parsed as any).password}
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className="h-6 px-2"
                        onClick={() => copyToClipboard((scannedData.parsed as any).password)}
                      >
                        <Copy className="w-3 h-3" />
                      </Button>
                    </div>
                  </>
                )}
                
                {(scannedData.parsed as any).hidden && (
                  <>
                    <div className="font-medium text-muted-foreground">Hidden</div>
                    <div className="font-medium">Yes</div>
                  </>
                )}
              </div>
            </div>
          )}

          {scannedData.type === 'vcard' && scannedData.parsed && (
            <div className="space-y-3">
              {(scannedData.parsed as any).fullName && (
                <div className="text-lg font-semibold">{(scannedData.parsed as any).fullName}</div>
              )}
              <div className="space-y-2 text-sm">
                {(scannedData.parsed as any).phone?.map((phone: string, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-muted-foreground" />
                    <a href={`tel:${phone}`} className="text-primary hover:underline">{phone}</a>
                  </div>
                ))}
                {(scannedData.parsed as any).email?.map((email: string, i: number) => (
                  <div key={i} className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-muted-foreground" />
                    <a href={`mailto:${email}`} className="text-primary hover:underline">{email}</a>
                  </div>
                ))}
                {(scannedData.parsed as any).organization && (
                  <div className="text-muted-foreground">🏢 {(scannedData.parsed as any).organization}</div>
                )}
                {(scannedData.parsed as any).title && (
                  <div className="text-muted-foreground">💼 {(scannedData.parsed as any).title}</div>
                )}
                {(scannedData.parsed as any).address && (
                  <div className="text-muted-foreground">📍 {(scannedData.parsed as any).address}</div>
                )}
              </div>
            </div>
          )}

          {scannedData.type === 'geo' && scannedData.parsed && (
            <div className="space-y-3">
              <div className="text-lg font-semibold">
                {(scannedData.parsed as any).latitude.toFixed(6)}, {(scannedData.parsed as any).longitude.toFixed(6)}
              </div>
              {(scannedData.parsed as any).altitude && (
                <div className="text-sm text-muted-foreground">
                  Altitude: {(scannedData.parsed as any).altitude}m
                </div>
              )}
              <a 
                href={`https://www.google.com/maps?q=${(scannedData.parsed as any).latitude},${(scannedData.parsed as any).longitude}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-primary hover:underline"
              >
                <MapPin className="w-4 h-4" />
                Open in Google Maps
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
          )}

          {scannedData.type === 'email' && scannedData.parsed && (
            <div className="space-y-3">
              <a 
                href={scannedData.raw}
                className="text-primary hover:underline flex items-center gap-1"
              >
                <Mail className="w-4 h-4" />
                {(scannedData.parsed as any).to}
              </a>
              {(scannedData.parsed as any).subject && (
                <div className="text-sm">
                  <span className="font-medium">Subject:</span> {(scannedData.parsed as any).subject}
                </div>
              )}
              {(scannedData.parsed as any).body && (
                <div className="text-sm">
                  <span className="font-medium">Body:</span> {(scannedData.parsed as any).body}
                </div>
              )}
              <Button asChild>
                <a href={scannedData.raw}>
                  <Mail className="w-4 h-4 mr-2" />
                  Open Email Client
                </a>
              </Button>
            </div>
          )}

          {scannedData.type === 'sms' && scannedData.parsed && (
            <div className="space-y-3">
              <div className="flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-muted-foreground" />
                <span className="font-medium">{(scannedData.parsed as any).number}</span>
              </div>
              {(scannedData.parsed as any).body && (
                <div className="text-sm bg-muted p-3 rounded-lg">
                  {(scannedData.parsed as any).body}
                </div>
              )}
              <Button asChild>
                <a href={scannedData.raw}>
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Send SMS
                </a>
              </Button>
            </div>
          )}

          {scannedData.type === 'tel' && scannedData.parsed && (
            <div className="space-y-3">
              <div className="text-2xl font-semibold">{scannedData.parsed as string}</div>
              <Button asChild>
                <a href={scannedData.raw}>
                  <Phone className="w-4 h-4 mr-2" />
                  Call Number
                </a>
              </Button>
            </div>
          )}

          {scannedData.type === 'event' && scannedData.parsed && (
            <div className="space-y-3">
              {(scannedData.parsed as any).summary && (
                <div className="text-lg font-semibold">{(scannedData.parsed as any).summary}</div>
              )}
              {(scannedData.parsed as any).location && (
                <div className="text-sm text-muted-foreground flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  {(scannedData.parsed as any).location}
                </div>
              )}
              {(scannedData.parsed as any).startDate && (
                <div className="text-sm">
                  <span className="font-medium">Start:</span> {(scannedData.parsed as any).startDate.toLocaleString()}
                </div>
              )}
              {(scannedData.parsed as any).endDate && (
                <div className="text-sm">
                  <span className="font-medium">End:</span> {(scannedData.parsed as any).endDate.toLocaleString()}
                </div>
              )}
              {(scannedData.parsed as any).description && (
                <div className="text-sm text-muted-foreground">
                  {(scannedData.parsed as any).description}
                </div>
              )}
            </div>
          )}

          {scannedData.type === 'text' && (
            <div className="p-3 bg-muted rounded-lg break-all text-sm font-mono whitespace-pre-wrap max-h-60 overflow-y-auto">
              {scannedData.raw}
            </div>
          )}

          <Separator />

          {/* Copy button for raw data */}
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => copyToClipboard(scannedData.raw)}
              className="flex-1"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 mr-2" />
                  Copy Raw Data
                </>
              )}
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => setScannedData(null)}
            >
              Clear
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-background to-muted/30">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-background/80 backdrop-blur-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary rounded-lg">
                <QrCode className="w-6 h-6 text-primary-foreground" />
              </div>
              <div>
                <h1 className="text-xl font-bold">QR Scanner</h1>
                <p className="text-sm text-muted-foreground hidden sm:block">Fast, private, client-side scanning</p>
              </div>
            </div>
            <Badge variant="secondary" className="gap-1">
              <Shield className="w-3 h-3" />
              100% Private
            </Badge>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        {/* Privacy Banner */}
        <Alert className="mb-6 border-green-200 bg-green-50 dark:bg-green-950/30 dark:border-green-900">
          <Shield className="h-4 w-4 text-green-600" />
          <AlertTitle className="text-green-800 dark:text-green-400">Your Privacy is Protected</AlertTitle>
          <AlertDescription className="text-green-700 dark:text-green-500">
            All scanning happens locally in your browser. No images or data are ever uploaded to any server.
          </AlertDescription>
        </Alert>

        {/* Scanner Section */}
        <div className="grid lg:grid-cols-2 gap-6 mb-8">
          <Card>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <CardHeader className="pb-0">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upload" className="gap-2">
                    <Upload className="w-4 h-4" />
                    Upload Image
                  </TabsTrigger>
                  <TabsTrigger value="camera" className="gap-2">
                    <Camera className="w-4 h-4" />
                    Use Camera
                  </TabsTrigger>
                </TabsList>
              </CardHeader>

              <CardContent className="pt-6">
                <TabsContent value="upload" className="mt-0">
                  <div
                    className={`relative border-2 border-dashed rounded-xl p-8 text-center transition-all cursor-pointer
                      ${isDragging ? 'border-primary bg-primary/5 scale-[1.02]' : 'border-muted-foreground/25 hover:border-primary/50 hover:bg-muted/50'}
                      ${isScanning ? 'pointer-events-none opacity-50' : ''}`}
                    onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
                    onDragLeave={() => setIsDragging(false)}
                    onDrop={handleDrop}
                    onClick={() => fileInputRef.current?.click()}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={handleFileSelect}
                      className="hidden"
                      aria-label="Select image file"
                    />
                    
                    {isScanning ? (
                      <div className="space-y-4">
                        <div className="w-12 h-12 mx-auto rounded-full border-4 border-primary border-t-transparent animate-spin" />
                        <p className="text-muted-foreground">Scanning for QR code...</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="w-16 h-16 mx-auto rounded-full bg-primary/10 flex items-center justify-center">
                          <Upload className="w-8 h-8 text-primary" />
                        </div>
                        <div>
                          <p className="font-medium">Drag & drop an image here</p>
                          <p className="text-sm text-muted-foreground">or click to select a file</p>
                        </div>
                        <p className="text-xs text-muted-foreground">
                          Supports PNG, JPEG, GIF, BMP, WebP
                        </p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="camera" className="mt-0">
                  <div className="space-y-4">
                    {cameraError && (
                      <Alert variant="destructive">
                        <AlertCircle className="h-4 w-4" />
                        <AlertTitle>Camera Error</AlertTitle>
                        <AlertDescription>{cameraError}</AlertDescription>
                      </Alert>
                    )}

                    <div className="relative aspect-video bg-black rounded-xl overflow-hidden">
                      <video
                        ref={videoRef}
                        className={`w-full h-full object-cover ${cameraActive ? 'block' : 'hidden'}`}
                        playsInline
                        muted
                      />
                      <canvas ref={canvasRef} className="hidden" />
                      
                      {!cameraActive && (
                        <div className="absolute inset-0 flex items-center justify-center bg-muted">
                          <div className="text-center space-y-3">
                            <Camera className="w-12 h-12 mx-auto text-muted-foreground" />
                            <p className="text-muted-foreground">Camera is off</p>
                          </div>
                        </div>
                      )}

                      {cameraActive && (
                        <div className="absolute inset-0 pointer-events-none">
                          <div className="absolute top-4 left-4">
                            <Badge variant="destructive" className="gap-1 animate-pulse">
                              <span className="w-2 h-2 bg-red-500 rounded-full" />
                              Recording
                            </Badge>
                          </div>
                          <div className="absolute inset-8 border-2 border-white/30 rounded-lg">
                            <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-white rounded-tl" />
                            <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-white rounded-tr" />
                            <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-white rounded-bl" />
                            <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-white rounded-br" />
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="flex gap-2">
                      {!cameraActive ? (
                        <Button onClick={startCamera} className="flex-1">
                          <Camera className="w-4 h-4 mr-2" />
                          Start Camera
                        </Button>
                      ) : (
                        <Button onClick={stopCamera} variant="destructive" className="flex-1">
                          <CameraOff className="w-4 h-4 mr-2" />
                          Stop Camera
                        </Button>
                      )}
                    </div>

                    <p className="text-xs text-muted-foreground text-center">
                      Point your camera at a QR code. Scanning is automatic.
                    </p>
                  </div>
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>

          {/* Results Panel */}
          <div className="space-y-4">
            <h2 className="text-lg font-semibold flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              Scanned Data
            </h2>
            
            {scannedData ? (
              renderScannedData()
            ) : (
              <Card className="border-dashed">
                <CardContent className="py-12 text-center">
                  <div className="space-y-3">
                    <div className="w-16 h-16 mx-auto rounded-full bg-muted flex items-center justify-center">
                      <QrCode className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <div>
                      <p className="font-medium text-muted-foreground">No QR code scanned yet</p>
                      <p className="text-sm text-muted-foreground">
                        Upload an image or use your camera to scan
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>

        {/* Information Section */}
        <div className="space-y-8">
          {/* Supported QR Code Types */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Info className="w-5 h-5" />
                Supported QR Code Types
              </CardTitle>
              <CardDescription>
                Our scanner can decode all common QR code formats
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {qrCodeTypes.map((item, index) => {
                  const IconComponent = {
                    Globe, Wifi, User, MapPin, Mail, MessageSquare, Phone, Calendar, FileText
                  }[item.icon] || FileText
                  
                  return (
                    <div 
                      key={index}
                      className="flex items-start gap-3 p-4 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                    >
                      <div className="p-2 rounded-lg bg-background">
                        <IconComponent className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-medium text-sm">{item.type}</h3>
                        <p className="text-xs text-muted-foreground">{item.description}</p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* FAQ Section */}
          <Card>
            <CardHeader>
              <CardTitle>Frequently Asked Questions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {faqItems.map((item, index) => (
                  <FAQItem key={index} question={item.question} answer={item.answer} />
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <QrCode className="w-4 h-4" />
              <span>QR Scanner - Free Online Tool</span>
            </div>
            <div className="flex items-center gap-1">
              <Shield className="w-4 h-4 text-green-500" />
              <span>All processing happens locally in your browser</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}

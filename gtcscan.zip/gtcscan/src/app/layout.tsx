import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "QR Code Scanner - Free Online QR Reader",
  description: "Free online QR code scanner. Scan QR codes from images or webcam. Supports URL, WiFi, vCard, Location, Email, SMS, Phone, and more. 100% private - all processing happens in your browser.",
  keywords: ["QR Code", "QR Scanner", "QR Reader", "Barcode Scanner", "WiFi QR", "vCard QR", "Free QR Scanner", "Online QR Reader"],
  authors: [{ name: "QR Scanner Team" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "QR Code Scanner - Free Online QR Reader",
    description: "Scan QR codes from images or webcam. 100% private, client-side processing.",
    url: "https://chat.z.ai",
    siteName: "QR Scanner",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "QR Code Scanner - Free Online QR Reader",
    description: "Scan QR codes from images or webcam. 100% private, client-side processing.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
